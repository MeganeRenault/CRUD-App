import { Routes } from '@angular/router';
import { ParameterComponent } from './parameter.component';

export const routes: Routes = [
  {
    path: '',
    component: ParameterComponent,
  },
];
